#include "scorer/req_excl_scorer.h"

#include "scorer/scorer.h"
#include <iostream>
namespace search {

ReqExclScorer::ReqExclScorer(Scorer* required, Scorer* excluded) {
  // TODO: Implement constructor.
	required_=required;
	excluded_=excluded;
}

ReqExclScorer::~ReqExclScorer() {
  // TODO: Implement destructor.
	delete required_;
	required_=NULL;
	delete excluded_;
	excluded_=NULL;
}

int ReqExclScorer::Next() {
  // TODO: Implement this function.
	score_=-1;
	//CHKCHK_:if(required_->Next()<kDocExhausted){
	//	if(excluded_->Advance(required_->doc())==required_->doc()){
	//		goto CHKCHK_;
	//	}
	//	score_=required_->score();
	//	doc_=required_->doc();
	//	return doc_;
	//}
	while(required_->Next()<kDocExhausted){
		if(excluded_->doc()!=required_->doc()){
			if(excluded_->doc()>required_->doc()){
			score_=required_->score();
			doc_=required_->doc();
			return doc_;
			}
			else if(excluded_->doc()<required_->doc()){
			if(excluded_->Advance(required_->doc())>required_->doc()){
			score_=required_->score();
			doc_=required_->doc();
			return doc_;}
			}
		}
	}
	score_=0;
	doc_=kDocExhausted;
	return kDocExhausted;	
}

float ReqExclScorer::score() {
  // TODO: Implement this function.
  return score_;
}

}  // namespace search
