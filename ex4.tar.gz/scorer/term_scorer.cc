#include "scorer/term_scorer.h"

#include <istream>
#include <math.h>
#include "index/storage_reader.h"

namespace search {

TermScorer::TermScorer(int df, std::istream* in, int begin,
                       StorageReader* storage_reader) {
  if (in == nullptr || storage_reader == nullptr || df==0) {
    // Mark this scorer as exhausted
    df_=df;
    post_=NULL;
    in_=in;
    if(in!=NULL){
      in_->seekg(begin,std::ios::beg);
    }
    storage_reader_=NULL;
    cost_=df;
    score_=-1;
  } else {
    // TODO: Implement constructor.
    doc_=-1;
    df_=df;
    post_=NULL;
    in_=in;
    in_->seekg(begin,std::ios::beg);
    storage_reader_=storage_reader;
    cost_=df;
    score_=-1;
  }
}

int TermScorer::Next() {
  // TODO: Implement this function.
  score_=-1;

  if(doc_ == kDocExhausted || storage_reader_ == NULL || in_ == NULL){
    score_=0;
    return kDocExhausted;
  }

  if(post_==NULL){
    post_=new Posting(in_);
    doc_=post_->doc_id();
    if(in_->good()){
	if(doc_!=-1&&doc_!=kDocExhausted){
		score_=(tf())*(log(((double)storage_reader_->num_docs())/df_));    
	}else if(storage_reader_==NULL){
		score_=0;    
	}
      return doc_;
    }
  }
  if(in_->good()){
    post_->Load(in_);
    doc_=post_->doc_id();
    if(in_->good()){
	if(doc_!=-1&&doc_!=kDocExhausted){
		score_=(tf())*(log(((double)storage_reader_->num_docs())/df_));    
	}else if(storage_reader_==NULL){
		score_=0;    
	}
    return doc_;
    }
  }
  
  doc_ = kDocExhausted;
  return kDocExhausted;
}

int TermScorer::tf() {
  // Implement this function.
  if(post_==NULL){
    return 0;
  }
  return (post_->tf());
}

float TermScorer::score() {
  // TODO: Implement this function.
  
  return score_;
}

}  // namespace search
