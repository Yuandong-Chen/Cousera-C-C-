#include "index/inverted_index_searcher.h"

#include <string>

#include "index/storage_reader.h"
#include "scorer/term_scorer.h"
#include "util/logging.h"
// TODO: Add headers you need.
#include <algorithm>
#include <iostream>
namespace search {

InvertedIndexSearcher::InvertedIndexSearcher(util::IO* io, int id) {
  // TODO: Implement constructor.
  io_=io;
  term_in_=io_->NewTermIn(id);
  posting_in_=io_->NewPostingIn(id);
  num_terms_=0;
  int postingSize = (io->kTermSize) + sizeof(int) + sizeof(int);
  //char *buffer = new char[postingSize];
  term_in_->seekg(0,std::ios::beg);
  /*while (term_in_->good()) {
    if (term_in_->read(buffer, postingSize)) {
      num_terms_++;
    }
  }*/
  term_in_->seekg(0,std::ios::beg);
  int begin=term_in_->tellg();
  term_in_->seekg(0,std::ios::end);
  int end=term_in_->tellg();
  num_terms_=(end-begin)/postingSize;
  closed=false;
  df_=0;
  offset_=0;
}

InvertedIndexSearcher::~InvertedIndexSearcher() {
  // TODO: Implement destructor.
  if(!closed){
  	Close();
  }
	
}

void InvertedIndexSearcher::Close() {
  // TODO: Implement this function.
	
	//io_->CloseAndDeleteTermIn(term_in_);
	//io_->CloseAndDeletePostingIn(posting_in_);
	closed=true;
}

int InvertedIndexSearcher::FindTerm(const std::string& term) {
  // TODO: Implement this function.
  
  bool isFind=false;
  int left=0;
  int right=num_terms()-1;
  int middle=(left+right)/2;
  int result_cmp;
  std::string term_=term;
  
  auto cmp = [=](std::string x,std::string y)->int {
	unsigned int i=0;
  	for(;i<=x.length()&&i<=y.length();i++){
		if(x[i]!=y[i]){
			return (x[i]-y[i]);
		}
	}

	return (x.length()-y.length());

	};
  
  if(cmp(term_,GetTerm(0))<0||cmp(term_,GetTerm(right))>0){
	return -1;
  }
  
  while(left<=right){
	//std::cout<<left<<" "<<right<<std::endl;
	middle=(left+right)/2;
	result_cmp=cmp(term_,GetTerm(middle));
	if(result_cmp<0){
		right=middle-1;
		
	}else if(result_cmp>0){
		left=middle+1;
		
	}else{
		isFind=true;
		break;
	}
  }
  
  if(isFind){
	
	int postingSize = (io_->kTermSize) + sizeof(int) + sizeof(int);
	char *buffer = new char[8];
	term_in_->seekg(middle*postingSize+(io_->kTermSize),std::ios::beg);
	term_in_->read(buffer, sizeof(int));
	offset_ = *(int*)buffer;
	term_in_->read(buffer, sizeof(int));
	df_ = *(int*)buffer;
	delete buffer;
	buffer=NULL;
	return middle;
  }

  return -1;
}

std::string InvertedIndexSearcher::GetTerm(int id) {
  CHECK(0 <= id && id < num_terms()) << "term_id " << id << " is out of range.";
  // TODO: Implement this function.
  int postingSize = (io_->kTermSize) + sizeof(int) + sizeof(int);
  term_in_->seekg(id*postingSize,std::ios::beg);
  char *buffer = new char[postingSize];
  term_in_->read(buffer,(io_->kTermSize));
  buffer[io_->kTermSize] = '\0';
  std::string term(buffer);
  delete buffer;
  buffer=NULL;
  return term;
  
}

TermScorer* InvertedIndexSearcher::NewTermScorer(
    const std::string& term, StorageReader* storage_reader) {
  // TODO: Implement this function.
  if(FindTerm(term)!=-1){
	//DebugString();
	posting_in_->seekg(0,std::ios::beg);
	return new TermScorer(df_, posting_in_, offset_, storage_reader);
  }
  //std::cout<<"nonono"<<std::endl;
  return new TermScorer(0, nullptr, 0, nullptr);
}

std::string InvertedIndexSearcher::DebugString() {
  // TODO: Implement this function.
  
  std::stringstream ss;
  std::string out="";
  int postingSize = (io_->kTermSize) + sizeof(int) + sizeof(int);
  int j=0;
  term_in_->seekg(0,std::ios::beg);
  for (;j<num_terms();j++) {
    //std::cout<<"enter!!!!!!"<<std::endl;
    //std::cout<<j<<std::endl;
    char *buffer = new char[postingSize];
    std::string add="";
    term_in_->read(buffer, (io_->kTermSize));
      buffer[io_->kTermSize] = '\0';
      std::string term(buffer);
      term_in_->read(buffer, sizeof(int));
      int plp = *(int*)buffer;
      term_in_->read(buffer, sizeof(int));
      int df = *(int*)buffer;
      ss<<term<<":";
      ss>>add;
      ss.clear();
      out+=add; 
      //std::cout<<add;
      posting_in_->seekg(plp,std::ios::beg);
      delete buffer;
      buffer=NULL;
      for(int i=0;i<df;i++){
	std::string add="";
	int first,second;	
	posting_in_->read((char*)&first,sizeof(int));
	posting_in_->read((char*)&second,sizeof(int));
	ss<<"<"<<first<<":"<<second<<">";
	ss>>add;
	ss.clear();
	out+=add;
	//std::cout<<add;
      }
      out+="\n";
	//std::cout<<std::endl;
    }
  return out;
}

}  // namespace search
