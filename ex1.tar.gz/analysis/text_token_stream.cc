#include "analysis/text_token_stream.h"

#include <istream>
// TODO: Add headers you need.
#include <cstring>
#include <string>
#include <iostream>
#include <utility>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <cstdlib>
#include <iomanip>
#include "analysis/token.h"

namespace search {

TextTokenStream::TextTokenStream(std::istream* in) {
  // TODO: Implement constructor.
  this->is=in;
  this->begin=0;		
}

bool TextTokenStream::HasNext() const {
  // TODO: Implement this function.
  char peek=(this->is)->peek();
  int rang;
  rang=peek;
  bool no_escape=(rang<58&&rang>47)||(rang<123&&rang>96)||(rang<91&&rang>64);
  while(!no_escape){
     (this->begin)++;
     (this->is)->get();
     if(is->eof()){
       return false;
     }
     peek=(this->is)->peek();
     rang=peek;
     no_escape=(rang<58&&rang>47)||(rang<123&&rang>96)||(rang<91&&rang>64);
  }
  if(!(is->eof())){
    return true;
  }
  return false;
}

Token TextTokenStream::Next() {
  // TODO: Implement this function.
  char peek=(this->is)->peek();
  int rang;
  rang=peek;
  bool no_escape=(rang<58&&rang>47)||(rang<123&&rang>96)||(rang<91&&rang>64);
  std::string term="";
  while(no_escape){
    term+=(this->is)->get();
    peek=(this->is)->peek();
    rang=peek;
    no_escape=(rang<58&&rang>47)||(rang<123&&rang>96)||(rang<91&&rang>64);
  }
  int length=term.length();
  int obegin=begin;
  begin+=length;
  Normalize(&term);
  return Token(term, obegin, begin);
}

}  // namespace search
