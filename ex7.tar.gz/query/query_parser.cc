#include "query/query_parser.h"

#include <string>
// TODO: Add headers you need.
#include <vector>
#include <sstream>
#include "query/query.h"
// TODO: Add headers you need.
#include "util/logging.h"
namespace search {

namespace {
bool IsOperator(std::string c) {
	return c == "&" || c == "|" || c == "-";
}

void PeelOffOuterBrackets(std::vector<std::string>& norms){
	
	unsigned int size=norms.size();
	int count=0;
	bool needDelete=false;
	if(norms[0]=="("&&norms[size-1]==")"){
		count=-1;
		needDelete=true;
		unsigned int i=1;
		for(;i<size;i++){
			if(norms[i]=="("){
				count--;
			}else if(norms[i]==")"){
				count++;
			}
			if(count>0){
				LOG(INFO)<<"illegal brackets as a)&(b";
				return;
			}
			if(count==0&&i!=size-1){
				needDelete=false;
				return;
			}
		}
		
		if(needDelete){
			norms.erase(norms.begin());
			norms.pop_back();
			PeelOffOuterBrackets(norms);
		}	
	}	
	
	return;
}

int FindSplitPoint(std::vector<std::string> norms){
	unsigned int size=norms.size();
	int and_=-1;
	int or_=-1;
	int minus_=-1;
	int count=0;
	unsigned int i=0;
	for(;i<size;i++){
		if(norms[i]=="("){
			count--;
		}else if(norms[i]==")"){
			count++;
		}else if(IsOperator(norms[i])&&count==0){
			char c=norms[i].c_str()[0];
			switch(c){
				case '&': and_=i;break;
				case '|': or_=i;break;
				case '-': minus_=i;break;
			}
		}
	}

	return (minus_>0)?minus_:((or_>0)?or_:((and_>0)?and_:-1));
}

const std::string MergeToString(std::vector<std::string> norms,int split_,int dir_){
	unsigned int size=norms.size();
	std::string left="";
	std::string right="";
	for(int i=0;i<split_;i++){
		left+=norms[i];
	}
	
	for(int j=split_+1;j<(int)size;j++){
		right+=norms[j];
	}
	
	if(dir_>0){
		const std::string right_=right;
		return right;	
	}else if(dir_<0){
		const std::string left_=left;
		return left;	
	}
	return "";	
}

std::vector<std::string> SplitToVector(const std::string str,const Analyzer& analyzer_){
	std::istringstream* istr=new std::istringstream(str);
	TokenStream* token_stream=analyzer_.NewQueryTokenStream(istr);
	std::vector<std::string> norms_; 
	while(token_stream->HasNext()){
		Token token=token_stream->Next();
		norms_.push_back(token.term());
	}
	if(norms_.size()%2==0){
		LOG(INFO)<<"Input is illegal! Check Brackets or Operators!";
	}
	return norms_;
}




}//namespace

Query* QueryParser::NewQuery(const std::string& str) {
  // TODO: Implement this function.
	std::vector<std::string> norms_=SplitToVector(str,analyzer_);
	PeelOffOuterBrackets(norms_);
	if(norms_.size()==1){
		return query_manager_->NewTermQuery(norms_[0]);
	}
	int split=FindSplitPoint(norms_);
	if(split==-1){
		LOG(INFO)<<"cannot split, error!";	
	}
	
	//need to iterate left string to find any possible same operator conductors.
	const std::string left=MergeToString(norms_,split,-1);
	const std::string right=MergeToString(norms_,split,1);
	char oper_=norms_[split].c_str()[0];
	const Query* right_parse=NewQuery(right);
	const Query* left_parse=NewQuery(left);
	std::vector<const Query*> queries;
	
	if(oper_=='-'){	
		return query_manager_->NewReqExclQuery(left_parse, right_parse);
	}else{
		//tackle left in this block
		queries.insert(queries.begin(),1,right_parse);
		queries.insert(queries.begin(),1,left_parse);
		char oper_tmp;
		int split_tmp;
		std::vector<std::string> norms_tmp;
		Query* left_parse_tmp;
		Query* right_parse_tmp;
		std::string left_tmp(left.c_str());
		std::string right_tmp;
		LOOP_:	
			norms_tmp=SplitToVector(left_tmp,analyzer_);
			PeelOffOuterBrackets(norms_tmp);
			split_tmp=FindSplitPoint(norms_tmp);
			if(split_tmp==-1){
				//LOG(INFO)<<"cannot split, error!";
				goto EXIT_;	
			}
			left_tmp=MergeToString(norms_tmp,split_tmp,-1);
			right_tmp=MergeToString(norms_tmp,split_tmp,1);
			oper_tmp=norms_[split_tmp].c_str()[0];
			right_parse_tmp=NewQuery(right_tmp);
			left_parse_tmp=NewQuery(left_tmp);
			if(oper_tmp==oper_){
				queries.erase(queries.begin());
				queries.insert(queries.begin(),1,right_parse_tmp);
				queries.insert(queries.begin(),1,left_parse_tmp);
				goto LOOP_;			
			}	
	}
	EXIT_:
	switch(oper_){
		case '&': return query_manager_->NewConjunctionQuery(queries); break;
		case '|': return query_manager_->NewDisjunctionQuery(queries); break;
		default: return NULL; break;
	}
	
	//
	return NULL;	
}


}  // namespace search
