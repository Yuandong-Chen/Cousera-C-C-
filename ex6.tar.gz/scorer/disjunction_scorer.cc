#include "scorer/disjunction_scorer.h"

#include <utility>
#include <vector>
// TODO: Add headers you need.
#include <algorithm>
#include "scorer/scorer.h"
#include "util/logging.h"

namespace search {

DisjunctionScorer::DisjunctionScorer(const std::vector<Scorer*>& scorers)
    : scorers_(scorers) {
  Init();
}

DisjunctionScorer::DisjunctionScorer(std::vector<Scorer*>&& scorers)
    : scorers_(std::move(scorers)) {
  Init();
}

void DisjunctionScorer::Init() {
  CHECK(scorers_.size() > 1)
      << "There should be at least 2 scorers in a disjunction scorer.";
  // TODO: Implement this function.
	//bool hasNULL=false;
  //check if has null scorer
	std::vector<Scorer*>::iterator iter=scorers_.begin();
	while(iter!=scorers_.end()){
		(*iter)->Next();
		iter++;
	}
  //sort the scorers according to its first doc_;
	
	
	std::sort(scorers_.begin(),scorers_.end(),[=](Scorer* s1, Scorer* s2)->bool{return (s1->doc()<s2->doc());});
	
}

DisjunctionScorer::~DisjunctionScorer() {
  // TODO: Implement destructor.
	for(unsigned int i=0;i<scorers_.size();i++){
		delete scorers_[i];
		scorers_[i]=NULL;
	}
	std::vector<Scorer*>().swap(scorers_);
}

int DisjunctionScorer::Next() {
  // TODO: Implement this function.
	score_=-1;
	if(scorers_.size()==0){
		doc_=kDocExhausted;
		score_=0;
		return kDocExhausted;	
	}
	auto myLess = [=](Scorer* s1, Scorer* s2)->bool{return (s1->doc()<s2->doc());};
	doc_=scorers_[0]->doc();
	score_=0;
	//bool needDelete=false;
	if(doc_<kDocExhausted){
		for(unsigned int i=0;i<scorers_.size();i++){
			if(scorers_[i]->doc()!=doc_){
				break;
			}
			score_+=scorers_[i]->score();
			scorers_[i]->Next();
		}
		std::sort(scorers_.begin(),scorers_.end(),myLess);
		return doc_;
	}
	score_=0;
	return 	kDocExhausted;
		
}

float DisjunctionScorer::score() {
  // TODO: Implement this function.
  return score_;
}

}  // namespace search
