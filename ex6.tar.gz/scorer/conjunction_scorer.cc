#include "scorer/conjunction_scorer.h"

#include <utility>
#include <vector>
// TODO: Add headers you need.
#include <algorithm>
#include "scorer/scorer.h"
#include "util/logging.h"
// TODO: Add headers you need.

namespace search {

ConjunctionScorer::ConjunctionScorer(const std::vector<Scorer*>& scorers)
    : scorers_(scorers) {
  Init();
}

ConjunctionScorer::ConjunctionScorer(std::vector<Scorer*>&& scorers)
    : scorers_(std::move(scorers)) {
  Init();
}

void ConjunctionScorer::Init() {
  CHECK(scorers_.size() > 1)
      << "There should be at least 2 scorers in a conjunction scorer.";
  // TODO: Implement this function.
	//bool hasNULL=false;
  //check if has null scorer
	std::vector<Scorer*>::iterator iter=scorers_.begin();
	while(iter!=scorers_.end()){
		(*iter)->Next();
		iter++;
	}
  //sort the scorers according to its first doc_;
	
	
	std::sort(scorers_.begin(),scorers_.end(),[=](Scorer* s1, Scorer* s2)->bool{return (s1->doc()<s2->doc());});
	
	
}

ConjunctionScorer::~ConjunctionScorer() {
  // TODO: Implement destructor.
	for(unsigned int i=0;i<scorers_.size();i++){
		delete scorers_[i];
		scorers_[i]=NULL;
	}
	std::vector<Scorer*>().swap(scorers_);
}

int ConjunctionScorer::Next() {
  // TODO: Implement this function.
	CHECK(scorers_.size() > 1)<< "There should be at least 2 scorers in a conjunction scorer.";
	score_=-1;
	bool isBreak=false;
	int first=scorers_.size()-1;
	int last=(first+1)%scorers_.size();
	
	while((scorers_[last]->doc()) < (scorers_[first]->doc())){
		if(scorers_[last]->Advance(scorers_[first]->doc())==kDocExhausted){
			isBreak=true;
			break;
		}
		first=last;
		last=(first+1)%scorers_.size();
	}

	if(!isBreak){
		doc_=scorers_[last]->doc();
		score_=0;
		for(unsigned int i=0;i<scorers_.size();i++){
			score_+=scorers_[i]->score();
		}
		scorers_[scorers_.size()-1]->Advance(scorers_[scorers_.size()-1]->doc());
		return doc_;
	}

	doc_=kDocExhausted;
	score_=0;
	return kDocExhausted;
}

float ConjunctionScorer::score() {
  // TODO: Implement this function.
  return score_;
}

}  // namespace search
