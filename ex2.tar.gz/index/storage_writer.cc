#include "index/storage_writer.h"

#include <string>

namespace search {

StorageWriter::~StorageWriter() {
  // TODO: Implement destructor.
}

void StorageWriter::Close() {
  // TODO: Implement this function.
  io->CloseAndDeleteStorageIndexOut(os_index);
  io->CloseAndDeleteStorageOut(os_storage);
}

void StorageWriter::AddStorage(const std::string& stored) {
  // TODO: Implement this function.
  os_storage->write((char*)stored.c_str(),stored.length());
  point+=stored.length();
  os_index->write((char*)&point,sizeof(int));
}

}  // namespace search
