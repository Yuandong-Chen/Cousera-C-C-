#include "analysis/query_token_stream.h"

#include <istream>
// TODO: Add headers you need.

#include "analysis/token.h"

namespace search {
namespace {

bool IsOperator(char c) {
  return c == '(' || c == ')' || c == '&' || c == '|' || c == '-';
}

}  // namespace

QueryTokenStream::QueryTokenStream(std::istream* in) {
  // TODO: Implement constructor.
  this->is=in;
  this->begin=0;
}

bool QueryTokenStream::HasNext() const {
  // TODO: Implement this function.
  char peek=(this->is)->peek();
  int rang;
  rang=peek;
  bool no_escape=(rang<58&&rang>47)||(rang<123&&rang>96)||(rang<91&&rang>64)||IsOperator(peek);
  while(!no_escape){
     (this->begin)++;
     (this->is)->get();
     if(is->eof()){
       return false;
     }
     peek=(this->is)->peek();
     rang=peek;
     no_escape=(rang<58&&rang>47)||(rang<123&&rang>96)||(rang<91&&rang>64)||IsOperator(peek);
  }
  if(!(is->eof())){
    return true;
  }
  return false;
}

Token QueryTokenStream::Next() {
  // TODO: Implement this function.
  char peek=(this->is)->peek();
  int rang;
  rang=peek;
  bool no_escape=(rang<58&&rang>47)||(rang<123&&rang>96)||(rang<91&&rang>64)||IsOperator(peek);
  std::string term="";
  while(no_escape){
    if(IsOperator(peek)&&term.length()==0){
	term+=(this->is)->get();
	break;
    }else if(IsOperator(peek)&&term.length()>0){
	break;
    }
    term+=(this->is)->get();
    peek=(this->is)->peek();
    rang=peek;
    no_escape=(rang<58&&rang>47)||(rang<123&&rang>96)||(rang<91&&rang>64)||IsOperator(peek);
  }
  int length=term.length();
  int obegin=begin;
  begin+=length;
  Normalize(&term);
  return Token(term, obegin, begin);
}

}  // namespace search
