#include "index/inverted_index_writer.h"

#include <string>
// TODO: Add headers you need.
#include <map>
#include <sstream>
#include <iostream>
#include <string.h>
#include <cstring>
#include "index/document.h"
#include "util/logging.h"
#include "analysis/analyzer.h"
#include "analysis/token.h"
#include "analysis/token_stream.h"
#include "posting.h"

// TODO: Add headers you need.

namespace search {

InvertedIndexWriter::~InvertedIndexWriter() {
  // TODO: Implement destructor.
  WriteAndClose();
  delete token_stream_;
  token_stream_=NULL;
}

void InvertedIndexWriter::AddDocument(Document* doc) {
  CHECK(doc->text()) << "Document is in lack of text.";

  // TODO: Implement this function.
  //token_stream_=doc->NewTokenStream(analyzer_);
  token_stream_=analyzer_.NewTextTokenStream(doc->text());
  //Need to Normalize the term
  //token_stream_=analyzer_.NewTextTokenStream(&std::cin);
  while(token_stream_->HasNext()){
    Token token = token_stream_->Next();
    //LOG(INFO) << token.DebugString();
    std::map< std::string,std::map< int,int >,myLess >::iterator iter=posting_list_.find(token.term());
    if(iter!=posting_list_.end()){
	(iter->second)[doc->doc_id()]++;
    }else{
	std::map< int, int > element_;
	element_.insert(std::make_pair(doc->doc_id(),1));
    	posting_list_.insert(std::make_pair(token.term(),element_));
    }
  }
}

void InvertedIndexWriter::WriteAndClose() {
  // TODO: Writes inverted index to term_out_ and posting_out_.
  std::map< std::string,std::map< int,int >,myLess >::iterator iter=posting_list_.begin();
  int termSize=io_->kTermSize;
  //int postingSize = termSize + sizeof(int) + sizeof(int);
  //char *buffer = new char[postingSize];
  //memset(buffer,' ',sizeof(char)*postingSize);
  int plp=0;
  while(iter!=posting_list_.end()){
	std::map< int, int >::iterator sub_iter=(iter->second).begin();
	//int length=sizeof(char)*(iter->first).length();
	//int padding=termSize-length;
	int df=(iter->second).size();
	//LOG(INFO)<<(iter->first)<<" "<<plp<<" "<<df;
	//int temp=(iter->first).length();
	//int temp=termSize;
	term_out_->write((char*)(iter->first).c_str(),termSize);
	//term_out_->write((char*)buffer,termSize-length);
	term_out_->write((char*)&plp,sizeof(int));
	term_out_->write((char*)&df,sizeof(int));
	plp+=(iter->second).size()*8;	
		while(sub_iter!=(iter->second).end()){
			Posting post(sub_iter->first,sub_iter->second);
			//std::cout<<(sub_iter->first)<<" "<<(sub_iter->second)<<std::endl;
			post.Write(posting_out_);
			//int doc_id=sub_iter->first;
			//int tf=sub_iter->second;
			//posting_out_->write((char*)&doc_id,sizeof(int));
			//posting_out_->write((char*)&tf,sizeof(int));
			sub_iter++;
		}
	
	iter++;
  }
  io_->CloseAndDeleteTermOut(term_out_);
  io_->CloseAndDeletePostingOut(posting_out_);
  term_out_=NULL;
  posting_out_=NULL;
  //delete buffer;
  //buffer=NULL;
}

std::string InvertedIndexWriter::DebugString(){
  // TODO: Implement this function.
  std::stringstream ss;
  std::string out="";
  std::map< std::string,std::map< int,int >,myLess >::iterator iter=posting_list_.begin();
  while(iter!=posting_list_.end()){
	std::map< int, int >::iterator sub_iter=(iter->second).begin();
		std::string add;
		ss<<(iter->first);
		ss>>add;
		out+=add+":";
		ss.clear();
		while(sub_iter!=(iter->second).end()){
			std::string add;
			std::stringstream ss;
			ss<<"<"<<(sub_iter->first)<<":"<<(sub_iter->second)<<">";
			ss>>add;
			ss.clear();
			out+=add;
			sub_iter++;
		}
	out+="\n";
	iter++;
  }
  return out;
  //return out.substr(0,out.length()-1);
}

}  // namespace search
