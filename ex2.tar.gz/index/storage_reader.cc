#include "index/storage_reader.h"

#include <string>

#include "util/io.h"
#include "util/logging.h"

namespace search {

StorageReader::StorageReader(util::IO* io) {
  // TODO: Implement this function.
  storage_index=new int[100];
  memset(storage_index,0,sizeof(int)*100);
  this->io=io;
  is_storage=io->NewStorageIn();
  is_index=io->NewStorageIndexIn();
  index_size=0; 
  while(is_index->read((char*)&storage_index[index_size],sizeof(int))){
	LOG(INFO)<<storage_index[index_size];
	index_size++;
  }
}

StorageReader::~StorageReader() {
  // TODO: Implement this function.
}

void StorageReader::Close() {
  // TODO: Implement this function.
  io->CloseAndDeleteStorageIn(is_index);
  io->CloseAndDeleteStorageIndexIn(is_storage);
}

std::string StorageReader::Stored(int doc) {
  CHECK(0 <= doc && doc < num_docs()) << "doc " << doc << " is out of range.";
  // TODO: Implement this function.
  int start=0;
  if(doc>0){
    start=storage_index[doc-1];
  }
  int end=storage_index[doc];
  int length=end-start;
  is_storage->seekg(start,std::ios::beg);
  char* buffer=new char[length+1];
  memset(buffer,0,sizeof(char)*(length+1));
  is_storage->read(buffer,length);
  std::string out(buffer);
  return out;
}

}  // namespace search
